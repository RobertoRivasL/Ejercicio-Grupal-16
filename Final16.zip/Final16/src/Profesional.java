import javax.swing.*;

class Profesional extends Usuario {
    private String titulo;
    private String fechaIngreso;

    public Profesional(String nombre, String titulo, String fechaIngreso) {
        super(nombre, "Profesional");
        this.titulo = titulo;
        this.fechaIngreso = fechaIngreso;
    }

    @Override
    public void analizarUsuario(JTextArea textArea) {
        super.analizarUsuario(textArea);
        textArea.append("Título: " + titulo + "\n");
        textArea.append("Fecha de ingreso: " + fechaIngreso + "\n");
    }
}
