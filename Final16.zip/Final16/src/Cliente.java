import javax.swing.*;

class Cliente extends Usuario {
    private int rut;
    private String nombres;
    private String apellidos;
    private int telefono;
    private String afp;
    private int sistemaSalud;
    private String direccion;
    private String comuna;
    private int edad;

    public Cliente(String nombre, int rut, String nombres, String apellidos, int telefono, String afp, int sistemaSalud, String direccion, String comuna, int edad) {
        super(nombre, "Cliente");
        this.rut = rut;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.telefono = telefono;
        this.afp = afp;
        this.sistemaSalud = sistemaSalud;
        this.direccion = direccion;
        this.comuna = comuna;
        this.edad = edad;

    }

    @Override
    public void analizarUsuario(JTextArea textArea) {
        super.analizarUsuario(textArea);
        textArea.append("RUT: " + rut + "\n");
        textArea.append("Nombres: " + nombres + "\n");
        textArea.append("Apellidos: " + apellidos + "\n");
        textArea.append("Teléfono: " + telefono + "\n");
        textArea.append("AFP: " + afp + "\n");
        if (sistemaSalud == 1) {
            textArea.append("Sistema de salud: Fonasa\n");
        } else {
            textArea.append("Sistema de salud: Isapre\n");
        }
        textArea.append("Dirección: " + direccion + "\n");
        textArea.append("Comuna: " + comuna + "\n");
        textArea.append("Edad: " + edad + "\n");

    }
}
