import javax.swing.*;

interface Asesoria {
    void analizarUsuario(JTextArea textArea);
}
