import javax.swing.*;

class Administrativo extends Usuario {
    private String area;
    private String experienciaPrevia;

    public Administrativo(String nombre, String area, String experienciaPrevia) {
        super(nombre, "Administrativo");
        this.area = area;
        this.experienciaPrevia = experienciaPrevia;
    }

    @Override
    public void analizarUsuario(JTextArea textArea) {
        super.analizarUsuario(textArea);
        textArea.append("Área: " + area + "\n");
        textArea.append("Experiencia previa: " + experienciaPrevia + "\n");
    }
}
