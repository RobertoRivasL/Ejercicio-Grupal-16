import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class InterfazGrafica extends JFrame implements ActionListener{
    private JTextField nombreField,rutField,nombresField,apellidosField,telefonoField,afpField,sistemaSaludField,direccionField,comunaField,edadField,tituloField,fechaIngresoField,areaField,experienciaPreviaField;
    private JComboBox<String> tipoUsuarioBox;
    private JButton agregarButton;
    private JButton listarButton;

    private JTextArea resultadoArea;

    private Listado listado;

    public InterfazGrafica(){
        super("Ingreso de Usuarios");

        listado = new Listado();

        setLayout(new BorderLayout());

        JPanel inputPanel = new JPanel();
        inputPanel.setLayout(new GridLayout(16,2));

        inputPanel.add(new JLabel("Tipo de Usuario:"));
        tipoUsuarioBox = new JComboBox<>(new String[]{"Profesional", "Administrativo", "Cliente"});
        tipoUsuarioBox.addActionListener(this);
        inputPanel.add(tipoUsuarioBox);

        inputPanel.add(new JLabel("Nombre:"));
        nombreField = new JTextField();
        inputPanel.add(nombreField);

        inputPanel.add(new JLabel("RUT:"));
        rutField = new JTextField();
        inputPanel.add(rutField);

        inputPanel.add(new JLabel("Nombres:"));
        nombresField = new JTextField();
        inputPanel.add(nombresField);

        inputPanel.add(new JLabel("Apellidos:"));
        apellidosField = new JTextField();
        inputPanel.add(apellidosField);

        inputPanel.add(new JLabel("Teléfono:"));
        telefonoField = new JTextField();
        inputPanel.add(telefonoField);

        inputPanel.add(new JLabel("AFP:"));
        afpField = new JTextField();
        inputPanel.add(afpField);

        inputPanel.add(new JLabel("Sistema de Salud:"));
        sistemaSaludField = new JTextField();
        inputPanel.add(sistemaSaludField);

        inputPanel.add(new JLabel("Dirección:"));
        direccionField = new JTextField();
        inputPanel.add(direccionField);

        inputPanel.add(new JLabel("Comuna:"));
        comunaField = new JTextField();
        inputPanel.add(comunaField);

        inputPanel.add(new JLabel("Edad:"));
        edadField = new JTextField();
        inputPanel.add(edadField);

        inputPanel.add(new JLabel("Título:"));
        tituloField = new JTextField();
        inputPanel.add(tituloField);

        inputPanel.add(new JLabel("Fecha de Ingreso:"));
        fechaIngresoField = new JTextField();
        inputPanel.add(fechaIngresoField);

        inputPanel.add(new JLabel("Área:"));
        areaField = new JTextField();
        inputPanel.add(areaField);

        inputPanel.add(new JLabel("Experiencia Previa:"));
        experienciaPreviaField = new JTextField();
        inputPanel.add(experienciaPreviaField);

        agregarButton = new JButton("Agregar Usuario");
        agregarButton.addActionListener(this);
        inputPanel.add(agregarButton);

        listarButton = new JButton("Listar Usuarios");
        listarButton.addActionListener(this);
        inputPanel.add(listarButton);

        add(inputPanel,BorderLayout.CENTER);

        resultadoArea = new JTextArea();
        resultadoArea.setEditable(false);
        add(new JScrollPane(resultadoArea),BorderLayout.EAST);

        actualizarCampos();

        pack();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e){
        if(e.getSource() == agregarButton){
            String tipoUsuario = (String)tipoUsuarioBox.getSelectedItem();
            String nombre = nombreField.getText();

            if(tipoUsuario != null && !nombre.isEmpty()){
                switch(tipoUsuario){
                    case "Profesional":
                        String titulo = tituloField.getText();
                        String fechaIngreso = fechaIngresoField.getText();

                        if(!titulo.isEmpty() && !fechaIngreso.isEmpty()){
                            listado.agregar(new Profesional(nombre,titulo,fechaIngreso));
                        }
                        break;
                    case "Administrativo":
                        String area = areaField.getText();
                        String experienciaPrevia = experienciaPreviaField.getText();

                        if(!area.isEmpty() && !experienciaPrevia.isEmpty()){
                            listado.agregar(new Administrativo(nombre,area,experienciaPrevia));
                        }
                        break;
                    case "Cliente":
                        int rut=Integer.parseInt(rutField.getText());
                        String nombres=nombresField.getText();
                        String apellidos=apellidosField.getText();
                        int telefono=Integer.parseInt(telefonoField.getText());
                        String afp=afpField.getText();
                        int sistemaSalud=Integer.parseInt(sistemaSaludField.getText());
                        String direccion=direccionField.getText();
                        String comuna=comunaField.getText();
                        int edad=Integer.parseInt(edadField.getText());

                        listado.agregar(new Cliente(nombre,rut,nombres,apellidos,telefono,afp,sistemaSalud,direccion,comuna,edad));
                        break;
                }
            }
        } else if(e.getSource() == listarButton){
            resultadoArea.setText("");
            listado.analizarUsuarios(resultadoArea);
        } else if(e.getSource() == tipoUsuarioBox){
            actualizarCampos();
        }
    }

    private void actualizarCampos(){
        String tipoUsuario = (String)tipoUsuarioBox.getSelectedItem();
        if(tipoUsuario != null){
            switch(tipoUsuario){
                case "Profesional":
                    tituloField.setEnabled(true);
                    fechaIngresoField.setEnabled(true);
                    areaField.setEnabled(false);
                    experienciaPreviaField.setEnabled(false);
                    rutField.setEnabled(false);
                    nombresField.setEnabled(false);
                    apellidosField.setEnabled(false);
                    telefonoField.setEnabled(false);
                    afpField.setEnabled(false);
                    sistemaSaludField.setEnabled(false);
                    direccionField.setEnabled(false);
                    comunaField.setEnabled(false);
                    edadField.setEnabled(false);
                    break;
                case "Administrativo":
                    tituloField.setEnabled(false);
                    fechaIngresoField.setEnabled(false);
                    areaField.setEnabled(true);
                    experienciaPreviaField.setEnabled(true);
                    rutField.setEnabled(false);
                    nombresField.setEnabled(false);
                    apellidosField.setEnabled(false);
                    telefonoField.setEnabled(false);
                    afpField.setEnabled(false);
                    sistemaSaludField.setEnabled(false);
                    direccionField.setEnabled(false);
                    comunaField.setEnabled(false);
                    edadField.setEnabled(false);
                    break;
                case "Cliente":
                    tituloField.setEnabled(false);
                    fechaIngresoField.setEnabled(false);
                    areaField.setEnabled(false);
                    experienciaPreviaField.setEnabled(false);
                    rutField.setEnabled(true);
                    nombresField.setEnabled(true);
                    apellidosField.setEnabled(true);
                    telefonoField.setEnabled(true);
                    afpField.setEnabled(true);
                    sistemaSaludField.setEnabled(true);
                    direccionField.setEnabled(true);
                    comunaField.setEnabled(true);
                    edadField.setEnabled(true);
                    break;
            }
        }
    }

    public static void main(String[] args){
        new InterfazGrafica();
    }
}