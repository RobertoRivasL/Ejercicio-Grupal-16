import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

class Listado {
    private List<Asesoria> usuarios;

    public Listado() {
        usuarios = new ArrayList<>();
    }

    public void agregar(Asesoria usuario) {
        usuarios.add(usuario);
    }

    public void analizarUsuarios(JTextArea textArea) {
        for (Asesoria usuario : usuarios) {
            usuario.analizarUsuario(textArea);
            textArea.append("\n");
        }
    }
}
