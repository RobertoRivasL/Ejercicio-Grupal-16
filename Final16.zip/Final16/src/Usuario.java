import javax.swing.*;

class Usuario implements Asesoria {
    private String nombre;
    private String tipoUsuario;

    public Usuario(String nombre, String tipoUsuario) {
        this.nombre = nombre;
        this.tipoUsuario = tipoUsuario;
    }

    public String getNombre() {
        return nombre;
    }

    public String getTipoUsuario() {
        return tipoUsuario;
    }

    @Override
    public void analizarUsuario(JTextArea textArea) {
        textArea.append("Tipo de usuario: " + tipoUsuario + "\n");
        textArea.append("Nombre de usuario: " + nombre + "\n");
    }
}
